#include<stdio.h>

int main(void){
    printf("Merhaba Dünya!\n");
    return 0;
}
