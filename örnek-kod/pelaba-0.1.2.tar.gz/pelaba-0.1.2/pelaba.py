#!/usr/bin/python3

print("Merhaba Dünya")
